"""Tool used to manage Abseil Python releases."""

import argparse
import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys

assert sys.version_info >= (3, 6), 'Python 3.6+ required'

_LOCAL_STAGING_DIR = '/tmp/absl-py-staging'

_BOLD_GREEN = '\033[1;32m'
_BOLD_RED = '\033[1;31m'
_END = '\033[0m'


def _print_with_color(message, color_prefix, file_hd=sys.stdout):
  print(f'{color_prefix}{message}{_END}', file=file_hd)


def run_cmd(label, cmd, dry_run):
  print('\n====', label, '====')
  cmd_line = ' '.join(shlex.quote(arg) for arg in cmd)
  prefix = '[dry] ' if dry_run else ''
  color = _BOLD_RED if dry_run else _BOLD_GREEN
  _print_with_color(f'{prefix}$ {cmd_line}', color)
  if not dry_run:
    subprocess.check_call(cmd, universal_newlines=True)


def _run_check_output(label, args, **kwargs):
  kwargs.setdefault('universal_newlines', True)
  print('\n====', label, '====')
  cmd_line = ' '.join(shlex.quote(arg) for arg in args)
  _print_with_color(f'$ {cmd_line}', _BOLD_GREEN)
  return subprocess.check_output(args, **kwargs)


def print_and_exit(message):
  _print_with_color(f'ERROR: {message}', _BOLD_RED, file_hd=sys.stderr)
  sys.exit(1)


@contextlib.contextmanager
def pushd(directory):
  current_dir = os.getcwd()
  os.chdir(directory)
  try:
    yield
  finally:
    os.chdir(current_dir)


class Syncer:
  """Class for syncing changes."""

  @property
  def public_github_repo(self):
    return 'git@github.com:abseil/abseil-py'

  def tag_pypi_release(self, flags):
    """Creates tag for pypi release."""
    self._clone_public_github_repo()
    pypi_version = flags.pypi_version
    self._check_setup_version(pypi_version)
    self._create_pypi_tag(pypi_version, dry_run=flags.dry_run)

  def _create_pypi_tag(self, pypi_version, *, dry_run):
    git_tag = self._get_release_tag(pypi_version)
    with pushd(_LOCAL_STAGING_DIR):
      run_cmd(
          'Creating git tags locally', ['git', 'tag', git_tag],
          dry_run=dry_run)
      run_cmd(
          'Publishing git tags', ['git', 'push', 'origin', git_tag],
          dry_run=dry_run)

  def _does_pypi_tag_exist(self, pypi_version):
    tag = self._get_release_tag(pypi_version)
    try:
      run_cmd(
          'Check if PyPI tag exists',
          ['git', 'rev-parse', '-q', '--verify', f'refs/tags/{tag}'],
          dry_run=False,
      )
    except subprocess.CalledProcessError:
      return False
    return True

  def _get_release_tag(self, pypi_version):
    return f'v{pypi_version}'

  def push_to_pypi(self, flags):
    """Pushes code from GitHub to PyPI."""
    self._check_setuptools_version()
    self._check_twine_is_installed()
    self._clone_public_github_repo()

    pypi_version = flags.pypi_version
    self._check_setup_version(pypi_version)
    with pushd(_LOCAL_STAGING_DIR):
      if not self._does_pypi_tag_exist(pypi_version):
        self._create_pypi_tag(pypi_version, dry_run=flags.dry_run)
      else:
        git_tag = self._get_release_tag(pypi_version)
        run_cmd(
            'Checking out PyPI tag', ['git', 'checkout', git_tag],
            dry_run=False)

      run_cmd('Running setup.py sdist bdist_wheel',
              [sys.executable, 'setup.py', 'sdist', 'bdist_wheel'],
              dry_run=False)
      run_cmd(
          'Uploading to PyPI. You can find the API token on '
          'https://valentine.corp.google.com/#/show/1666121061237791',
          ['twine', 'upload', '-u', '__token__', 'dist/*'],
          dry_run=flags.dry_run)

  def _check_setuptools_version(self):
    version_str = _run_check_output(
        'Checking setuptools version',
        [sys.executable, '-c',
         'import setuptools; print(setuptools.__version__)'])
    version = tuple(int(s) for s in version_str.split('.')[:2])
    if version < (36, 2):
      print_and_exit('The installed setup tools version ({}) is too old. '
                     'setuptools >= 36.2 required.\n'
                     'Run pip install setuptools --upgrade'.format(version_str))

  def _check_twine_is_installed(self):
    """Checks that twine is installed."""
    try:
      run_cmd('Checking twine is installed', ['twine', '--version'],
              dry_run=False)
    except subprocess.CalledProcessError:
      print_and_exit('Cannot find twine, make sure it is available. '
                     'Instructions: https://pypi.python.org/pypi/twine')

  def _check_setup_version(self, pypi_version):
    """Checks that the PyPI version number matches the one in setup.py."""
    setup_file = os.path.join(_LOCAL_STAGING_DIR, 'setup.py')
    if not os.path.exists(setup_file):
      print_and_exit(f'Cannot find setup.py file "{setup_file}"')
    with open(setup_file) as fh:
      setup_content = fh.read()
    version_re = re.compile(r"\n\s+version='((\d+\.)*\d+)',\n")
    matches = version_re.findall(setup_content)
    if len(matches) != 1:
      print_and_exit(
          'Found no or more than one versions in setup.py, content:\n{}'.format(
              setup_content))
    if pypi_version != matches[0][0]:
      print_and_exit(
          'Version specified in setup.py ({}) does not match flag '
          '--pypi_version={}'.format(
              matches[0][0], pypi_version))

  def _clone_public_github_repo(self):
    if os.path.exists(_LOCAL_STAGING_DIR):
      shutil.rmtree(_LOCAL_STAGING_DIR)
    run_cmd('Cloning Abseil GitHub repo',
            ['git', 'clone', self.public_github_repo, _LOCAL_STAGING_DIR],
            dry_run=False)


def _create_flag_parser():
  """Returns the argparse flag parser."""
  syncer = Syncer()

  common_parser_kwargs = dict(
      formatter_class=argparse.ArgumentDefaultsHelpFormatter)
  parser = argparse.ArgumentParser(
      description='Abseil Python release manager.', **common_parser_kwargs)
  parser.add_argument(
      '--nodry_run', action='store_false', dest='dry_run',
      help=argparse.SUPPRESS)
  parser.add_argument(
      '--dry_run', action='store_true',
      help='By default, it avoids running commands that will push changes '
           'publicly, though it may still run commands that only make local '
           'changes. Specify --nodry_run to push changes publicly.')

  subparsers = parser.add_subparsers(help='The command to execute.')

  def _add_pypi_version_arg(parser):
    parser.add_argument(
        '--pypi_version', required=True,
        help=('The version number of the PyPI release, '
              'must match the one in setup.py.'))

  tag_pypi_release_parser = subparsers.add_parser(
      'tag_pypi_release',
      help='Create the git tag a PyPI release is built from.',
      **common_parser_kwargs)
  tag_pypi_release_parser.set_defaults(command=syncer.tag_pypi_release)
  _add_pypi_version_arg(tag_pypi_release_parser)

  push_to_pypi_parser = subparsers.add_parser(
      'push_to_pypi',
      help=('Push code from GitHub to PyPI. A release tag will be '
            'created if one doesn\'t exist'),
      **common_parser_kwargs)
  _add_pypi_version_arg(push_to_pypi_parser)
  push_to_pypi_parser.set_defaults(command=syncer.push_to_pypi)

  help_parser = subparsers.add_parser('help', help='Show help',
                                      **common_parser_kwargs)
  def _help(unused_flags):
    parser.print_help()
    return True
  help_parser.set_defaults(command=_help)

  parser.set_defaults(command=_help)

  return parser


def main():
  parser = _create_flag_parser()
  flags = parser.parse_args()
  hide_footer = flags.command(flags)
  if hide_footer:
    return

  if flags.dry_run:
    _print_with_color(
        '\nDry run finished successfully, local staging directory: {}'.format(
            _LOCAL_STAGING_DIR),
        _BOLD_GREEN)
  else:
    _print_with_color('\nRelease manager finished successfully.', _BOLD_GREEN)


if __name__ == '__main__':
  main()
