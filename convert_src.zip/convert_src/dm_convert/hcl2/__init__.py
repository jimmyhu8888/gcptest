"""For package documentation, see README"""

from .api import load, loads
