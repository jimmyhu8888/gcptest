"""In normal instalation, _version.py is written by vcversioner. We reproduce it by hand here.
"""
__version__ = '3.0.1'
__sha__ = 'gd16713a'
__revision__ = 'gd16713a'
