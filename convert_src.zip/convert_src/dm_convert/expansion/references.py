"""Util to handle references during expansion."""
import re
import jsonpath
import yaml


# Generally the regex is for this pattern: $(ref.NAME.PATH)
# if no PATH the whole object is used since $(ref.NAME) is a valid reference
# NOTE: This will find matches when a reference is present, but the 2nd group
# does NOT necessarily match the 'path' in the reference.
REF_PATTERN = re.compile(r'\$\(ref\.([^).]*)(\..*)?\)')

# Regex for the beginning of a reference.
REF_PREFIX_PATTERN = re.compile(r'\$\(ref\.')

# Create a SafeDumper that doesn't do aliases
noalias_dumper = yaml.dumper.SafeDumper
noalias_dumper.ignore_aliases = lambda self, data: True


def HasReference(string):
  """Returns true if the string contains a reference.

  We are only looking for the first part of a reference, from there we assume
  the user meant to use a reference, and will fail at a later point if no
  complete reference is found.

  Args:
    string: The string to parse to see if it contains  '$(ref.'.

  Returns:
    True if there is at least one reference inside the string.

  Raises:
      ExpansionReferenceError: If we see '$(ref.' but do not find a complete
          reference, we raise this error.
  """
  return ReferenceMatcher(string).FindReference()


def _BuildReference(name, path):
  """Takes name and path and returns '$(ref.name.path)'.

  Args:
    name: String, name of the resource being referenced.
    path: String, jsonPath to the value being referenced, if none whole
    object is references.

  Returns:
    String, the complete reference string in the expected format.
  """
  if not path:
    return '$(ref.%s)' % (name)
  return '$(ref.%s.%s)' % (name, path)


def _ExtractWithJsonPath(ref_obj, name, path, raise_exception=True):
  """Given a path and an object, use jsonpath to extract the value.

  Args:
    ref_obj: Dict obj, the thing being referenced.
    name: Name of the resource being referenced, for the error message.
    path: Path to follow on the ref_obj to get the desired value.
    raise_exception: boolean, set to False and this function will return None
        if no value was found at the path instead of throwing an exception.

  Returns:
    Either the value found at the path, or if raise_exception=False, None.

  Raises:
    ExpansionReferenceError: if there was a error when evaluation the path, or
        no value was found.
  """
  if not path:
    return ref_obj
  try:
    result = jsonpath.jsonpath(ref_obj, path)
    #  jsonpath should either return a list or False
    if not isinstance(result, list):
      if raise_exception:
        raise Exception('No value found.')
      return None
    # If jsonpath returns a list of a single item, it is lying.
    # It really found that item, and put it in a list.
    # If the reference is to a list, jsonpath will return a list of a list.
    if len(result) == 1:
      return result[0]
    # But if jsonpath returns a list with multiple elements, the path involved
    # wildcards, and the user expects a list of results.
    return result
  # This will usually be an IndexOutOfBounds error, but not always...
  except Exception as e:  # pylint: disable=broad-except
    if raise_exception:
      raise ExpansionReferenceError(
          _BuildReference(UnbindName(name), path), str(e))
    return None


def PopulateReferences(node, output_map):
  """Will replace references with the values they reference.

  Args:
    node: object to traverse.
    output_map: Map of resource name to map of output object name to output
        value. If present, we will replace references with the values they
        reference.

  Returns:
    The node with all references populated.
  """
  def _PopulateReferences(node, rm, output_map):
    """Replaces reference strings with their value."""
    if rm.name not in output_map:
      return node
    # It is possible that an output value and real resource share a name.
    # In this case, a path could be valid for the real resource but not the
    # output. So we don't fail, we let the reference exists as is.
    value = _ExtractWithJsonPath(output_map[rm.name], rm.name, rm.path,
                                 raise_exception=True)

    if value is None:
      return

    reference = _BuildReference(rm.name, rm.path)

    # If the node to replace is just the reference, we can replace it with
    # a non string object (i.e: list, dict)
    if node == reference:
      return value

    # Otherwise, convert the value to a string
    if isinstance(value, list) or isinstance(value, dict):
      value = yaml.dump(value, default_flow_style=False,
                        Dumper=noalias_dumper)
    return node.replace(reference, value)

  return _TraverseNode(node, _PopulateReferences, output_map)


def ListReferences(node, references):
  """Returns a (name, path) tuple of all references we find."""
  def _ListReferences(node, rm, references):
    references.append((rm.name, rm.path))
    return node

  return _TraverseNode(node, _ListReferences, references)


def BindName(name, prefix, targets):
  """Updates the name provided with the prefix if it is found in targets.

  Args:
    name: Name found in the reference being bound.
    prefix: Prefix to bind the name to, seperated by a '%'.
    targets: List of names that can be bound.

  Returns:
    If a name is already bound, do nothing. Elif name is found in targets,
    bind it with prefix. Else, bind it to '%raw%'.
  """
  if '%' in name:
    return name
  elif name in targets:
    return prefix + '%' + name
  else:
    return '%raw%' + name


def BindReferences(node, prefix, targets):
  """Uses _TraverseNode to bind all references."""
  def _BindReferences(node, rm, unused_arg):
    return node.replace(_BuildReference(rm.name, rm.path),
                        _BuildReference(BindName(rm.name, prefix, targets),
                                        rm.path))

  return _TraverseNode(node, _BindReferences, prefix)


def UnbindName(name):
  """Removes the name binding from reference names."""
  if '%' not in name:
    return name
  return name.split('%')[-1]


def CleanBoundReferences(node):
  """Uses _TraverseNode to unbind all references."""
  def _CleanBoundReferences(node, rm, unused_arg):
    return node.replace(_BuildReference(rm.name, rm.path),
                        _BuildReference(UnbindName(rm.name), rm.path))

  return _TraverseNode(node, _CleanBoundReferences)


def _TraverseNode(node, callback, arg=None):
  """Traverse a dict/list/element to find and resolve references.

  Same as DocumentReferenceHandler.java. This function traverses a dictionary
  that can contain dicts, lists, and elements.

  Args:
    node: Object to traverse: dict, list, or string
    callback: function to run when we find a reference, must take 3 arguments.
      The first is node, the second is the ReferenceMatcher object, and the
      third is arg. It must return node, the first argument.
    arg: argument to callback

  Returns:
    The node.
  """
  if isinstance(node, dict):
    for key in node:
      node[key] = _TraverseNode(node[key], callback, arg)
  elif isinstance(node, list):
    for i in range(len(node)):
      node[i] = _TraverseNode(node[i], callback, arg)
  elif isinstance(node, str):
    rm = ReferenceMatcher(node)
    while rm.FindReference():
      node = callback(node, rm, arg)
  return node


class ReferenceMatcher(object):
  """Finds and extracts references from strings.

  Same as DocumentReferenceHandler.java. This class is meant to be similar to
  the re matcher class, but specifically tuned for references.
  """
  content = None
  name = None
  path = None

  def __init__(self, content):
    self.content = content

  def FindReference(self):
    """Returns True if the string contains a reference and saves it.

    Returns:
      True if the content still contains a reference. If so, it also updates the
      name and path values to that of the most recently found reference. At the
      same time it moves the pointer in the content forward to be ready to find
      the next reference.

    Raises:
      ExpansionReferenceError: If we see '$(ref.' but do not find a complete
          reference, we raise this error.
    """

    # First see if the content contains '$(ref.'
    if not REF_PREFIX_PATTERN.search(self.content):
      return False

    # If so, then we say there is a reference here.
    # Next make sure we find NAME and some PATH with the close paren
    match = REF_PATTERN.search(self.content)
    if not match:
      # Has '$(ref.' but not '$(ref.NAME.PATH)'
      raise ExpansionReferenceError(self.content, 'Malformed reference.')

    # The regex matcher can only tell us that a complete reference exists.
    # We need to count parentheses to find the end of the reference.
    # Consider "$(ref.NAME.path())())" which is a string containing a reference
    # and ending with "())"

    open_group = 1  # Count the first '(' in '$(ref...'
    end_ref = 0     # To hold the position of the end of the reference
    end_name = match.end(1)  # The position of the end of the name

    # Iterate through the path until we find the matching close paren to the
    # open paren that started the reference.
    for i in range(end_name, len(self.content)):
      c = self.content[i]
      if c == '(':
        open_group += 1
      elif c == ')':
        open_group -= 1

      # Once we have matched all of our open parens, we have found the end.
      if open_group == 0:
        end_ref = i
        break

    if open_group != 0:
      # There are unmatched parens.
      raise ExpansionReferenceError(self.content, 'Malformed reference.')

    # Save the name
    self.name = match.group(1)
    # Skip the period after name, and save the path
    self.path = self.content[end_name + 1: end_ref]

    # Move the content forward to be ready to find the next reference
    self.content = self.content[end_ref + 1:]

    return True


class ExpansionReferenceError(Exception):
  """Exception raised when jsonPath cannot find the referenced value.

  Attributes:
    reference: the reference processed that results in the error
    message: the detailed message of the error
  """

  def __init__(self, reference, message):
    self.reference = reference
    self.message = message + ' Reference: ' + str(reference)
    super(ExpansionReferenceError, self).__init__(self.message)
